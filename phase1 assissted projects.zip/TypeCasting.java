package Demo;

public class TypeCasting{
	public static void main(String[] args)
	{
		int a=10;
		double b=a;// implicit type casting
		double c=10.77;
		int d=(int)c; //explicit type casting
		System.out.println("value of a is"+a);
		System.out.println("value of a is"+b);
		System.out.println("value of a is"+c);
		System.out.println("value of a is"+d);
		
	}
}
	


