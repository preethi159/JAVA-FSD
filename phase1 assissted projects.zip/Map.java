package Demo;
import java.util.HashMap;


public class Map {
	public static void main(String[] args)
	{
		HashMap<String,Integer> model=new HashMap<String,Integer>();
		model.put("Audi",1990);
		model.put("Thar",2010);
		model.put("Innova",1970);
	
	for( String i : model.keySet() )
	{
		System.out.println("key:"+" "+i+", "+"value:"+" "+model.get(i));
		
	}
	}
}

	

