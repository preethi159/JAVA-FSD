package Demo;

public class Method {
	public void display1()//without parameter
	{
		System.out.println("welcome to java");
	}
	public void disp2(int value)//with parameter
	{
		System.out.println("value is:"+value);
	}
	static int display1(int x, int y) //method overloading
	{
		  return x + y;
		}

		static double display1(double x, double y) {
		  return x + y;
		}
public static void main(String[] args)
{
	Method obj=new Method();
	obj.display1();
	obj.disp2(50);
	int myNum1 = display1(8, 5);
	  double myNum2 = display1(4.3, 6.26);
	  System.out.println("int: " + myNum1);
	  System.out.println("double: " + myNum2);
	
}
}

