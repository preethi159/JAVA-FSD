package Demo;

public class Constructor {
	String modelname;
	int modelyear;
	int x;
	public Constructor()//default constructor
	{
	 x=5;
	}
	public Constructor( String name, int year)
	{
		modelname=name;
		modelyear=year;
		
	}
	public static void main(String[] args)
	{
		Constructor obj=new Constructor("benz",1995);
		Constructor obj2=new Constructor();
		System.out.println("Car modelname and year is :"+" "+obj.modelname+" "+obj.modelyear);
		System.out.println(obj2.x);
		
	}
	

}
