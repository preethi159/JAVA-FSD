package Demo;

    class Details
{
	private String name="Hello";
	public String fname = "arya";
	protected String lname="raj";
	
	
	{
	System.out.println("private name:"+" "+name);
	}
}
	public class AccessSpecifier
	   {
		
	  public static void main(String[] args)
	  {
		Details obj=new Details();
		System.out.println("print public name:"+" "+obj.fname);
		System.out.println("print protected name:"+" "+obj.lname);
		
	    }
	}
	
	
	


