package practiceProg;
	
abstract class Bike
{
abstract void mileage();
void colour() {
System.out.println("Black");
}
}
class Pulsar extends Bike{
void speed() {
System.out.println("70km/hr");
}
void mileage() {
System.out.println("45km/hr");
}


}
public class AbstractionProg {

public static void main(String[] args) {
Pulsar obj=new Pulsar();
obj.speed();
obj.mileage();
obj.colour();


}

}
