package practiceProg;

public class ThreadProg extends Thread {
	public void display()
	{
		System.out.println("Welcome to java");
	}

public static void main(String[] args)
{
ThreadProg obj=new ThreadProg();
obj.display();


}

}
