package handlingprog;
class MyException extends Exception
{
	public MyException()
	{
		System.out.println("hello");
	}
	public MyException(String msg)

	{
		super(msg);//for passing the custom message to super class
		String text=msg;
		System.out.println("valid "+text);
	}
}
public class ThrowEg {
	public static void main(String[] args)
	{
	try {
		
		int a=10;
		int b=20;
		if(a>b)
		{
			throw new MyException("a>b");//custom exception and message
		}
	}
	
	catch(Exception e)
	{ 
		
		System.out.println(e);
	}
	

}
}
