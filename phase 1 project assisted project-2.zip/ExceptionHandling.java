package practiceProg;


class MyownException extends Exception{
public MyownException() 
{

}
public MyownException(String info) 
{
super(info);

}
}
public class ExceptionHandling{

public static void main(String[] args) {
int amount=50000;
try 
{
if(amount>0) 
 {
throw new MyownException("Insufficient balance,try again");
 }
}
catch(Exception e)
{
System.out.println(e);
}


}

}
