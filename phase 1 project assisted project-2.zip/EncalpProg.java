package practiceProg;


class Value{
int a;
int b;
Value(int a,int b){
this.a=a;
this.b=b;
}
void getValue() {
int Ans=a+b;
System.out.println("Ans is "+Ans);
}
}
public class EncalpProg {

public static void main(String[] args) {
Value obj=new Value(90,20);
obj.getValue();



}

}
