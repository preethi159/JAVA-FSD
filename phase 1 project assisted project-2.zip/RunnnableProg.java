package practiceProg;


class Number implements Runnable{
public void run() {
for(int i=0;i<5;i++) {
System.out.println("Main "+i);
}
}
}
class Number1 implements Runnable{
public void run() {
for(int j=0;j<5;j++) {
System.out.println("Sub "+j);
}

}
}
public class RunnnableProg {
public static void main(String[]args) {
Number obj1=new Number();
Number1  obj2=new Number1 ();
Thread t1=new Thread(obj1);
Thread t2=new Thread(obj2);
t1.start();
t2.start();
}

}
