package practiceProg;


public class Polymorphism {
	
void dis(int registerno,int grade) 
{
System.out.println("The regno is "+registerno + " grade is "+grade);

}
void dis(String Student,int registerno,int grade) 
{
System.out.println("The regno is "+registerno + " name is "+ Student +" mark is "+grade);
}
void dis(int registerno) 
{
System.out.println("The regno is "+registerno);
}
public static void main(String[]args) {
Polymorphism myobj=new Polymorphism();
myobj.dis(122005089,98);
myobj.dis(122005088);
myobj.dis("arun",122005078,89);

}

}
