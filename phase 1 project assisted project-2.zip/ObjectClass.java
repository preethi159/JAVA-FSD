package practiceProg;


class Employee{
    void display1(int EmpId,String name) 
    {
   System.out.println("EmpID is "+EmpId);
   System.out.println("Name is "+name);
 
    }
}
public class ObjectClass {
public static void main(String[]args) {
Employee obj=new Employee();
obj.display1(12005105,"Surya");

}


}
