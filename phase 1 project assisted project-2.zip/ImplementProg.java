package practiceProg;


interface Name1{
default void dis() {
System.out.println("welcome to Java");
}
}
interface Name2{
default void dis() {
System.out.println("Java is quite fun");
}
}
public class ImplementProg implements Name1,Name2
{
public void dis() {
Name1.super.dis();
Name2.super.dis();
}


public static void main(String[] args) {
	ImplementProg obj=new ImplementProg();
obj.dis();

}

}
