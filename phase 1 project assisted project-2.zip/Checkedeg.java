package handlingprog;

public class Checkedeg {
public static void main(String[] args) throws ArithmeticException
{
	try{
		int a=90;
	if(a>20)
	{
		throw new ArithmeticException("incorrect no");
	}
	else
	{
		System.out.println("enter no less than 20 ");
	}
	}
    finally
    {
    	System.out.println("finally part");
    }
    
     
}
}


