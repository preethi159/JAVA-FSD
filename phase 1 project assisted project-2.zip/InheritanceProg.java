package practiceProg;


class Student{
void dis1() {
System.out.println(" student : Harini");

}
}
class Info extends Student {
void dis2() {
System.out.println(" marks: 486");
}
}
public class InheritanceProg {

public static void main(String[] args) {
Student obj1=new Student();
obj1.dis1();
Info obj2=new Info();
obj2.dis2();
obj2.dis1();

}

}
