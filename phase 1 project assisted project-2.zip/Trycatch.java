package assistedProg;

public class Trycatch {
		public static void main(String[] args) {
		try 
		{
		   int num[]= {1,2,3,4};
		System.out.println(num[9]);
		}
		catch(Exception e)
		{
         System.out.println(e);
		}

		}
}
		

		



