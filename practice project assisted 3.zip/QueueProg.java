package assistedProg;
import java.util.LinkedList;
import java.util.Queue;
public class QueueProg {
	
    public static void main(String[]args)
    {
      Queue<String> qobj=new LinkedList<String>();
       qobj.add("Thar");
       qobj.add("Innova");
       qobj.add("Ecco");
       qobj.add("Audi");
       qobj.add("Toyota");
       System.out.println("Queue head = " + qobj.element());
       System.out.println("Removing element from queue = " + qobj.remove());
       System.out.println("After removing head of queue = " + qobj);

}

}