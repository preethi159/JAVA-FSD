package assistedProg;



import java.util.Stack;
public class Stackprog {
public static void main(String[]args) {
Stack qobj=new Stack();
qobj.push("Pulsar");
qobj.push("Fzx");
qobj.push("Royal Enfield");
qobj.push("Java");

System.out.println("The total elements are "+qobj);
System.out.println("The elements popped is "+qobj.pop());
System.out.println("The Remaining elements are "+qobj);
}
}

